const express = require('express');
const router = express.Router();
const User = require('../models/User');
const crypto = require('crypto');

// Function to generate OTP
function generateOTP() {
    return crypto.randomInt(100000, 999999).toString();
}

// Send OTP (Example using a placeholder function, replace with actual email/SMS sending logic)
async function sendOTP(email, otp) {
    console.log(`Sending OTP ${otp} to ${email}`);
    // Implement your email or SMS sending here
    return true;
}

// Route to generate and send OTP
router.post('/send-otp', async (req, res) => {
    const { email } = req.body;

    try {
        // Generate OTP
        const otp = generateOTP();
        const otpExpiry = new Date(Date.now() + 10 * 60 * 1000); // OTP valid for 10 minutes

        let user = await User.findOne({ email });
        if (!user) {
            user = new User({ email });
        }

        user.otp = otp;
        user.otpExpiry = otpExpiry;
        await user.save();

        if (await sendOTP(email, otp)) {
            res.status(200).json({ message: 'OTP sent successfully' });
        } else {
            res.status(500).json({ message: 'Failed to send OTP' });
        }
    } catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
});

// Route to verify OTP
router.post('/verify-otp', async (req, res) => {
    const { email, otp } = req.body;

    try {
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(400).json({ message: 'User not found' });
        }

        if (user.otp === otp && new Date(user.otpExpiry) > new Date()) {
            user.isVerified = true;
            user.otp = null;
            user.otpExpiry = null;
            await user.save();

            res.status(200).json({ message: 'OTP verified successfully' });
        } else {
            res.status(400).json({ message: 'Invalid or expired OTP' });
        }
    } catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
});

module.exports = router;
